let songs = [
    {
        name: "Flares",
        artist: "NIVIRO",
        img: "cover8",
        src: "song8"
    },
    {
        name: "Phoenix",
        artist: "Halvorsen, Netrum",
        img: "cover2",
        src: "song2"
    },
    {
        name: "Father",
        artist: "Diamond Eyes",
        img: "cover3",
        src: "song3"
    },
    {
        name: "Anonymous Music",
        artist: "Unknown",
        img: "cover1",
        src: "song1"
    },
    {
        name: "Bittersweet",
        artist: "Roses, Time To Talk",
        img: "cover4",
        src: "song4"
    },
    {
        name: "Time",
        artist: "Syn Cole",
        img: "cover5",
        src: "song5"
    },
    {
        name: "Lights",
        artist: "Whales",
        img: "cover10",
        src: "song10"
    },
    {
        name: "Never Give Up",
        artist: "Steve Hartz",
        img: "cover11",
        src: "song11"
    },
    {
        name: "Memory",
        artist: "RUD, Elektronomia",
        img: "cover12",
        src: "song12"
    },
    {
        name: "Victory",
        artist: "Poylow",
        img: "cover6",
        src: "song6"
    },
    {
        name: "Grow",
        artist: "VØR, Alisky",
        img: "cover7",
        src: "song7"
    },
    {
        name: "Firefly",
        artist: "Andromedik",
        img: "cover9",
        src: "song9"
    },
    {
        name: "Chasing Stars",
        artist: "STAR SEED",
        img: "cover13",
        src: "song13"
    }
]