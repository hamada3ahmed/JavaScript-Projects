const quizArr = [
    {
        question:"What does HTML stand for?",
        opt1:"Hyperlinks Text Mark Language",
        opt2:"Hyper Text Markup Language",
        opt3:"Hyper Tag Markup Language",
        opt4:"Hyper Tool Multi Language",
        ans:"ans2"
    },
    {
        question:"What does CSS stand for?",
        opt1:"Computer Style Sheets",
        opt2:"Colorful Style Sheets",
        opt3:"Cascading Style Sheets",
        opt4:"Creative Style Sheets",
        ans:"ans3"
    },
    {
        question:"What does XML stand for?",
        opt1:"eXecutale Markup Language",
        opt2:"eXtensible Markup Language",
        opt3:"eXamine Multiple Language",
        opt4:"eXtra Multi-Program Language",
        ans:"ans2"
    },
    {
        question:"What does PHP stand for?",
        opt1:"Hypertext Programming",
        opt2:"Hometext Preprocessor",
        opt3:"Hypertext Preprogramming",
        opt4:"Hypertext Preprocessor",
        ans:"ans4"
    },
    {
        question:"What does SQL stand for?",
        opt1:"Stylesheet Query Language",
        opt2:"Structured Query Language",
        opt3:"Stylish Query Language",
        opt4:"Statement Query Language",
        ans:"ans2"
    }
];